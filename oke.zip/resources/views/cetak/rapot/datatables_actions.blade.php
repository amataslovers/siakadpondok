<div class='btn-group' style="width: 100px">
    <a href="{{ route('cetakRapotDownload', $ID_HISTORY_KELAS) }}" class='btn btn-info btn-sm' target="_blank">
        <i class="fa fa-print" aria-hidden="true"> Cetak</i>
    </a>
</div>
