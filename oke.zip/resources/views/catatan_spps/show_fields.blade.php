<!-- Id Catatan Spp Field -->
<div class="form-group">
    {!! Form::label('ID_CATATAN_SPP', 'Id Catatan Spp:') !!}
    <p>{!! $catatanSpp->ID_CATATAN_SPP !!}</p>
</div>

<!-- Id History Kelas Field -->
<div class="form-group">
    {!! Form::label('ID_HISTORY_KELAS', 'Id History Kelas:') !!}
    <p>{!! $catatanSpp->ID_HISTORY_KELAS !!}</p>
</div>

<!-- Tanggal Bayar Field -->
<div class="form-group">
    {!! Form::label('TANGGAL_BAYAR', 'Tanggal Bayar:') !!}
    <p>{!! $catatanSpp->TANGGAL_BAYAR !!}</p>
</div>

<!-- Jenis Pembayaran Field -->
<div class="form-group">
    {!! Form::label('JENIS_PEMBAYARAN', 'Jenis Pembayaran:') !!}
    <p>{!! $catatanSpp->JENIS_PEMBAYARAN !!}</p>
</div>

<!-- No Referensi Field -->
<div class="form-group">
    {!! Form::label('NO_REFERENSI', 'No Referensi:') !!}
    <p>{!! $catatanSpp->NO_REFERENSI !!}</p>
</div>

<!-- Keterangan Field -->
<div class="form-group">
    {!! Form::label('KETERANGAN', 'Keterangan:') !!}
    <p>{!! $catatanSpp->KETERANGAN !!}</p>
</div>

<!-- Total Bayar Field -->
<div class="form-group">
    {!! Form::label('TOTAL_BAYAR', 'Total Bayar:') !!}
    <p>{!! $catatanSpp->TOTAL_BAYAR !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $catatanSpp->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $catatanSpp->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $catatanSpp->deleted_at !!}</p>
</div>

