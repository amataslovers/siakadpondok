<table class="table table-responsive table-hover table-bordered" id="nilais-table"  style="width: 100%">
    <thead>
        <tr>
            <th>#</th>
            <th>NIS</th>
            <th>Nama Murid</th>
            <th>Mata Pelajaran</th>
            <th>Kelas</th>
            <th>Semester</th>
            <th>Tahun Ajaran</th>
            <th>NILAI UTS</th>
            <th>NILAI UAS</th>
            <th width="120px">Action</th>
        </tr>
    </thead>
    <tfoot>
            <tr>
                <th>#</th>
                <th>NIS</th>
                <th>Nama Murid</th>
                <th>Mata Pelajaran</th>
                <th>Kelas</th>
                <th>Semester</th>
                <th>Tahun Ajaran</th>
                <th>NILAI UTS</th>
                <th>NILAI UAS</th>
                <th width="120px">Action</th>
            </tr>
    </tfoot>
</table>

