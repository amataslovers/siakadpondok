<!-- Id Nilai Karakter Field -->
<div class="form-group">
    {!! Form::label('ID_NILAI_KARAKTER', 'Id Nilai Karakter:') !!}
    <p>{!! $nilaiKarakter->ID_NILAI_KARAKTER !!}</p>
</div>

<!-- Id History Kelas Field -->
<div class="form-group">
    {!! Form::label('ID_HISTORY_KELAS', 'Id History Kelas:') !!}
    <p>{!! $nilaiKarakter->ID_HISTORY_KELAS !!}</p>
</div>

<!-- Ijin Field -->
<div class="form-group">
    {!! Form::label('IJIN', 'Ijin:') !!}
    <p>{!! $nilaiKarakter->IJIN !!}</p>
</div>

<!-- Sakit Field -->
<div class="form-group">
    {!! Form::label('SAKIT', 'Sakit:') !!}
    <p>{!! $nilaiKarakter->SAKIT !!}</p>
</div>

<!-- Alfa Field -->
<div class="form-group">
    {!! Form::label('ALFA', 'Alfa:') !!}
    <p>{!! $nilaiKarakter->ALFA !!}</p>
</div>

<!-- Akhlaq Field -->
<div class="form-group">
    {!! Form::label('AKHLAQ', 'Akhlaq:') !!}
    <p>{!! $nilaiKarakter->AKHLAQ !!}</p>
</div>

<!-- Kebersihan Field -->
<div class="form-group">
    {!! Form::label('KEBERSIHAN', 'Kebersihan:') !!}
    <p>{!! $nilaiKarakter->KEBERSIHAN !!}</p>
</div>

<!-- Kerajinan Field -->
<div class="form-group">
    {!! Form::label('KERAJINAN', 'Kerajinan:') !!}
    <p>{!! $nilaiKarakter->KERAJINAN !!}</p>
</div>

<!-- Kerajinan Field -->
<div class="form-group">
    {!! Form::label('KETEKUNAN', 'Ketekunan:') !!}
    <p>{!! $nilaiKarakter->KETEKUNAN !!}</p>
</div>


<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $nilaiKarakter->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $nilaiKarakter->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $nilaiKarakter->deleted_at !!}</p>
</div>

