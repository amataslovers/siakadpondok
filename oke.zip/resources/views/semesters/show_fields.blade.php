<!-- Id Semester Field -->
<div class="form-group">
    {!! Form::label('ID_SEMESTER', 'Id Semester:') !!}
    <p>{!! $semester->ID_SEMESTER !!}</p>
</div>

<!-- Id Tahun Ajaran Field -->
<div class="form-group">
    {!! Form::label('ID_TAHUN_AJARAN', 'Id Tahun Ajaran:') !!}
    <p>{!! $semester->ID_TAHUN_AJARAN !!}</p>
</div>

<!-- Semester Field -->
<div class="form-group">
    {!! Form::label('SEMESTER', 'Semester:') !!}
    <p>{!! $semester->SEMESTER !!}</p>
</div>

<!-- Status Field -->
<div class="form-group">
    {!! Form::label('STATUS', 'Status:') !!}
    <p>{!! $semester->STATUS !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $semester->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $semester->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $semester->deleted_at !!}</p>
</div>

