<!-- Id Sanksi Field -->
<div class="form-group">
    {!! Form::label('ID_SANKSI', 'Id Sanksi:') !!}
    <p>{!! $sanksi->ID_SANKSI !!}</p>
</div>

<!-- Nama Sanksi Field -->
<div class="form-group">
    {!! Form::label('NAMA_SANKSI', 'Nama Sanksi:') !!}
    <p>{!! $sanksi->NAMA_SANKSI !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $sanksi->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $sanksi->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $sanksi->deleted_at !!}</p>
</div>

