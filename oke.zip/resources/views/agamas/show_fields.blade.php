<!-- Id Agama Field -->
<div class="form-group">
    {!! Form::label('ID_AGAMA', 'Id Agama:') !!}
    <p>{!! $agama->ID_AGAMA !!}</p>
</div>

<!-- Nama Field -->
<div class="form-group">
    {!! Form::label('NAMA', 'Nama:') !!}
    <p>{!! $agama->NAMA !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $agama->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $agama->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $agama->deleted_at !!}</p>
</div>

