<!-- Id Nilai Field -->
<div class="form-group">
    {!! Form::label('ID_NILAI', 'Id Nilai:') !!}
    <p>{!! $nilaiAkademik->ID_NILAI !!}</p>
</div>

<!-- Id Detail Mapel Field -->
<div class="form-group">
    {!! Form::label('ID_PENGAMPU', 'Id Detail Mapel:') !!}
    <p>{!! $nilaiAkademik->ID_PENGAMPU !!}</p>
</div>

<!-- Nis Field -->
<div class="form-group">
    {!! Form::label('NIS', 'Nis:') !!}
    <p>{!! $nilaiAkademik->NIS !!}</p>
</div>

<!-- Nilai Uts Field -->
<div class="form-group">
    {!! Form::label('NILAI_UTS', 'Nilai Uts:') !!}
    <p>{!! $nilaiAkademik->NILAI_UTS !!}</p>
</div>

<!-- Nilai Uas Field -->
<div class="form-group">
    {!! Form::label('NILAI_UAS', 'Nilai Uas:') !!}
    <p>{!! $nilaiAkademik->NILAI_UAS !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $nilaiAkademik->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $nilaiAkademik->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $nilaiAkademik->deleted_at !!}</p>
</div>

