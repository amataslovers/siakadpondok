<table class="table table-responsive table-hover table-bordered" id="ijazah-table"  style="width: 100%">
        <thead>
            <tr>
                <th>#</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Ijazah</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
    
    