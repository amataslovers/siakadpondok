<!-- Id Pelanggaran Murid Field -->
<div class="form-group">
    {!! Form::label('ID_PELANGGARAN_MURID', 'Id Pelanggaran Murid:') !!}
    <p>{!! $pelanggaranMurid->ID_PELANGGARAN_MURID !!}</p>
</div>

<!-- Id Peraturan Field -->
<div class="form-group">
    {!! Form::label('ID_PERATURAN', 'Id Peraturan:') !!}
    <p>{!! $pelanggaranMurid->ID_PERATURAN !!}</p>
</div>

<!-- Id History Kelas Field -->
<div class="form-group">
    {!! Form::label('ID_HISTORY_KELAS', 'Id History Kelas:') !!}
    <p>{!! $pelanggaranMurid->ID_HISTORY_KELAS !!}</p>
</div>

<!-- Tanggal Melanggar Field -->
<div class="form-group">
    {!! Form::label('TANGGAL_MELANGGAR', 'Tanggal Melanggar:') !!}
    <p>{!! $pelanggaranMurid->TANGGAL_MELANGGAR !!}</p>
</div>

<!-- Keterangan Field -->
<div class="form-group">
    {!! Form::label('KETERANGAN', 'Keterangan:') !!}
    <p>{!! $pelanggaranMurid->KETERANGAN !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $pelanggaranMurid->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $pelanggaranMurid->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $pelanggaranMurid->deleted_at !!}</p>
</div>

