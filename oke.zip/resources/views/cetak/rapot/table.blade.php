<table class="table table-responsive table-hover table-bordered" id="rapot-table"  style="width: 100%">
        <thead>
            <tr>
                <th>#</th>
                <th>NIS</th>
                <th>Nama</th>
                <th>Kelas</th>
                <th>Semester</th>
                <th>Action</th>
            </tr>
        </thead>
    </table>
    
    