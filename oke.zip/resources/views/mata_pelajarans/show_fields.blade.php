<!-- Kode Mapel Field -->
<div class="form-group">
    {!! Form::label('KODE_MAPEL', 'Kode Mapel:') !!}
    <p>{!! $mataPelajaran->KODE_MAPEL !!}</p>
</div>

<!-- Nama Field -->
<div class="form-group">
    {!! Form::label('NAMA', 'Nama:') !!}
    <p>{!! $mataPelajaran->NAMA !!}</p>
</div>

<!-- Nama Arab Field -->
<div class="form-group">
    {!! Form::label('NAMA_ARAB', 'Nama Arab:') !!}
    <p>{!! $mataPelajaran->NAMA_ARAB !!}</p>
</div>
