<!-- Id Detail Keluarga Field -->
<div class="form-group">
    {!! Form::label('ID_DETAIL_KELUARGA', 'Id Detail Keluarga:') !!}
    <p>{!! $detailKeluarga->ID_DETAIL_KELUARGA !!}</p>
</div>

<!-- Nis Field -->
<div class="form-group">
    {!! Form::label('NIS', 'Nis:') !!}
    <p>{!! $detailKeluarga->NIS !!}</p>
</div>

<!-- Id Keluarga Murid Field -->
<div class="form-group">
    {!! Form::label('ID_KELUARGA_MURID', 'Id Keluarga Murid:') !!}
    <p>{!! $detailKeluarga->ID_KELUARGA_MURID !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $detailKeluarga->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $detailKeluarga->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $detailKeluarga->deleted_at !!}</p>
</div>

