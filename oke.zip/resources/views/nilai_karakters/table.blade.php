<table class="table table-responsive table-hover table-bordered" id="nilais-table"  style="width: 100%">
    <thead>
        <tr>
            <th>#</th>
            <th>NIS</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Semester</th>
            <th>Ijin</th>
            <th>Sakit</th>
            <th>Alfa</th>
            <th>Akhlaq</th>
            <th>Kebersihan</th>
            <th>Kerajinan</th>
            <th>Ketekunan</th>
            <th>Action</th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <th>#</th>
            <th>NIS</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Semester</th>
            <th>Ijin</th>
            <th>Sakit</th>
            <th>Alfa</th>
            <th>Akhlaq</th>
            <th>Kebersihan</th>
            <th>Kerajinan</th>
            <th>Ketekunan</th>
            <th>Action</th>
        </tr>
    </tfoot>
</table>
    
    