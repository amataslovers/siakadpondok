<!-- Id Perizinan Murid Field -->
<div class="form-group">
    {!! Form::label('ID_PERIZINAN_MURID', 'Id Perizinan Murid:') !!}
    <p>{!! $perizinanMurid->ID_PERIZINAN_MURID !!}</p>
</div>

<!-- Id History Kelas Field -->
<div class="form-group">
    {!! Form::label('ID_HISTORY_KELAS', 'Id History Kelas:') !!}
    <p>{!! $perizinanMurid->ID_HISTORY_KELAS !!}</p>
</div>

<!-- Jenis Field -->
<div class="form-group">
    {!! Form::label('JENIS', 'Jenis:') !!}
    <p>{!! $perizinanMurid->JENIS !!}</p>
</div>

<!-- Keterangan Field -->
<div class="form-group">
    {!! Form::label('KETERANGAN', 'Keterangan:') !!}
    <p>{!! $perizinanMurid->KETERANGAN !!}</p>
</div>

<!-- Tanggal Field -->
<div class="form-group">
    {!! Form::label('TANGGAL', 'Tanggal:') !!}
    <p>{!! $perizinanMurid->TANGGAL !!}</p>
</div>

<!-- Total Hari Field -->
<div class="form-group">
    {!! Form::label('TOTAL_HARI', 'Total Hari:') !!}
    <p>{!! $perizinanMurid->TOTAL_HARI !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $perizinanMurid->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $perizinanMurid->updated_at !!}</p>
</div>

<!-- Deleted At Field -->
<div class="form-group">
    {!! Form::label('deleted_at', 'Deleted At:') !!}
    <p>{!! $perizinanMurid->deleted_at !!}</p>
</div>

